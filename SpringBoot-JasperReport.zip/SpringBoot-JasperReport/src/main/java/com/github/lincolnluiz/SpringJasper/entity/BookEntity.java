package com.github.lincolnluiz.SpringJasper.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "livro")
public class BookEntity {
    @Id
    @Column(name = "id_livro")
    private String id;
    @Column(name = "titulo")
    private String title;
    @Column(name = "autor")
    private String author;
}
