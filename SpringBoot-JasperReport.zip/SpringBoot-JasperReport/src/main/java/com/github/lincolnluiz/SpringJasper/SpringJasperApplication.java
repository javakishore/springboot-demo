package com.github.lincolnluiz.SpringJasper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringJasperApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringJasperApplication.class, args);
	}
}
